(function() {
	$(function(){
		
		$("div#panel").show();
		$("#toggle a").toggle();
	});
}).call(this);